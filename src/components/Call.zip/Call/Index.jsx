import React, { useState, useEffect, useRef } from "react";
import { useLocation } from "react-router";
import { Container } from "react-bootstrap";
import SimplePeer from "simple-peer";

import { useUserMedia } from "./useMediaHook";
import UserList from "./UserList";
//import CallNotification from "./CallNotification";
import { useSelector } from "react-redux";
import CallNotification from "./CallNotification";

const AudioCall = () => {
  const [receivedCall, setReceivedCall] = useState(false);
  const [caller, setCaller] = useState("");
  const [callerName, setCallerName] = useState("");
  const [callerSignal, setCallerSignal] = useState("");
  const [callAccept, setCallAccepted] = useState(false);
  //const [callSocketId, setCallerSocketId] = useState("");
  const [callEnded, setCallEnded] = useState(false);
  const { isLoggedIn, token, socket, socketId } = useSelector(
    (state) => state.auth,
  );
  //const { user } = useSelector((state) => state.user);

  const location = useLocation();
  const { user } = location.state || {};
  const myVideo = useRef(null);
  const userVideo = useRef(null);
  const { stream } = useUserMedia(myVideo);
  const connectionRef = useRef();

  useEffect(() => {
    console.log("socketId:", socketId);
    console.log("socket:", socket);
    console.log("user from redux:", user);
    console.log("Token from redux:", token);

    if (!isLoggedIn) return;

    socket.on("onlineUsers", (onlineUsers) => {
      console.log("Received onlineUsers:", onlineUsers);
      setUsers(onlineUsers);
    });

    const handleInconningCall = (data) => {
      console.log("📞 Incoming call event received!", data);
      setReceivedCall(true);
      setCaller(data.from); // this is the socket id
      setCallerName(data.name);
      setCallerSignal(data.signal);
    };

    const handleRejectedCall = (data) => {
      console.log("callRejected invoked", data);
      alert(`Call Rejected from ${data.name}`);
      setReceivedCall(false);
      setCallAccepted(false);
    };
    const handleCallEnd = (data) => {
      alert(`Call is Ended from ${data.name}`);
      setReceivedCall(false);
      setCallAccepted(false);
      setCallEnded(false);
      connectionRef.current.destroy();
      if (userVideo.current) {
        userVideo.current.srcObject = null;
      }
    };

    socket.on("callToUser", handleInconningCall);
    socket.on("callRejected", handleRejectedCall);
    socket.on("callEnded", handleCallEnd);

    return () => {
      if (socket) {
        socket.off("callToUser", handleInconningCall);
        socket.off("callRejected", handleRejectedCall);
        socket.off("connect_error");
        socket.off("userList");
        socket.off("onlineUsers");
        socket.disconnect();
      }
    };
  }, [isLoggedIn, token, socket]);

  const callToUser = (id) => {
    if (!stream) {
      console.error("Stream is not available yet");
      return;
    }

    //Initiating peer
    const peer = new SimplePeer({
      initiator: true,
      trickle: false,
      stream: stream,
    });

    // I need to send this signals to backend
    peer.on("signal", (data) => {
      console.log("🛠 Emitting callToUser event with:", {
        callToUserId: id,
        signalData: data,
        from: localStorage.getItem("userId"),
        name: localStorage.getItem("userName"),
      });
      // ✅ Ensure `socket` is defined before using it
      if (typeof socket !== "undefined") {
        socket.emit("callToUser", {
          callToUserId: id,
          signalData: data,
          from: socketId,
          name: "dinesh",
        });
      } else {
        console.error("Socket is not defined");
      }
    });

    //I need to attach stream (video) to peer
    peer.on("stream", (stream) => {
      //userVideo.current.srcObject = stream;
      if (userVideo.current) {
        userVideo.current.srcObject = stream;
        userVideo.current
          .play()
          .catch((error) => console.error("Autoplay failed:", error));
      }
    });

    //This event is run only once when call is accepted
    socket.once("callAccepted", (data) => {
      console.log("call is accepted", data);
      setCallAccepted(true);
      setCaller(data.from);
      peer.signal(data.signal);
    });

    connectionRef.current = peer;
  };

  //reject call
  const handleRejectCall = () => {
    console.log("call rejectred");
    setReceivedCall(false);
    setCallAccepted(false);
    socket.emit("reject-call", {
      to: caller,
      name: localStorage.getItem("userName"), // this is username which wil popup with name in alrt
    });
  };

  // accept Call
  const handleAcceptCall = () => {
    setCallAccepted(true);

    const peer = new SimplePeer({
      initiator: false,
      trickle: false,
      stream: stream,
    });

    peer.on("signal", (data) => {
      socket.emit("answerCall", { signal: data, to: caller, from: socketId });
    });

    peer.on("stream", (stream) => {
      //userVideo.current.srcObject = stream;
      if (userVideo.current) {
        userVideo.current.srcObject = stream;
        userVideo.current
          .play()
          .catch((error) => console.error("Autoplay failed:", error));
      }
    });

    connectionRef.current = peer;

    // ✅ Ensure this runs last
    peer.signal(callerSignal);
  };

  //End call
  const leaveCall = () => {
    setReceivedCall(false);
    setCallAccepted(false);
    setCallEnded(false);
    connectionRef.current.destroy();
    if (userVideo.current) {
      userVideo.current.srcObject = null;
    }

    socket.emit("call-ended", {
      to: caller,
      name: "dinesh",
    });
  };

  if (!isLoggedIn) {
    return <div>Please log in to use audio calls</div>;
  }

  return (
    <Container className="mt-5">
      <h1>Audio Calls</h1>

      <h3>All Users</h3>
      <UserList callUser={callToUser} />

      {receivedCall && !callAccept ? (
        <CallNotification
          callerName={callerName}
          onAccept={handleAcceptCall}
          onReject={handleRejectCall}
        />
      ) : null}

      {callAccept && !callEnded ? (
        <div>
          <button onClick={leaveCall}>End Call</button>
        </div>
      ) : null}

      <div>
        <h2>My Video</h2>
        <video ref={myVideo} autoPlay muted></video>
      </div>
      <div>
        <h2>userVideo </h2>
        <video id="remove-video" ref={userVideo} autoplay muted></video>
      </div>
    </Container>
  );
};

export default AudioCall;
