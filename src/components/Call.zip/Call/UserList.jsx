import { useState, useEffect } from "react";
import { useSelector } from "react-redux";

const UserList = ({ callUser }) => {
  const { userList, userId } = useSelector((state) => state.auth);

  // Add a loading state
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (Array.isArray(userList) && userId) {
      setLoading(false);
    }
  }, [userList, userId]);

  if (loading) {
    return <p>Loading users...</p>;
  }
  const handleCallClick = (userId) => {
    console.log("callign user id", userId);
    callUser(userId);
  };

  return (
    <div>
      <h3>User List</h3>
      <ul>
        {userList
          .filter((user) => user.id !== userId) // Exclude current user
          .map((user) => (
            <li key={user.id}>
              {user.name} -
              <span
                style={{ color: user.status === "Online" ? "green" : "red" }}
              >
                {user.status}
              </span>
              <button onClick={() => handleCallClick(user.id)}>Call</button>
            </li>
          ))}
      </ul>
    </div>
  );
};

export default UserList;
