import React from "react";
import { Modal, Button } from "react-bootstrap";

/*
 * popup notification when someone is calling
 * here two button Reject and Accept
 */

const CallNotification = ({ callerName, onAccept, onReject }) => {
  return (
    <div className="fixed inset-0 flex items-center justify-center bg-black bg-opacity-50">
      <div className="bg-white p-6 rounded-2xl shadow-lg text-center">
        <h2 className="text-xl font-semibold mb-4">
          {callerName} is calling...
        </h2>
        <div className="flex gap-4 justify-center">
          <button
            className="px-4 py-2 bg-green-500 text-white rounded-lg"
            onClick={onAccept}
          >
            ✅ Accept
          </button>
          <button
            className="px-4 py-2 bg-red-500 text-white rounded-lg"
            onClick={onReject}
          >
            ❌ Reject
          </button>
        </div>
      </div>
    </div>
  );
};

export default CallNotification;
